#include<stdio.h>
int main(void)
{
    int i=65536;
    int h,num;
    for(i;i>=1;i)
    {
        i/=2;
        num++;
    }
    printf("%d",num);
    getchar();
    return 0;
}

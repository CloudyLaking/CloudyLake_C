/*
	��ʾ�ַ��ͺ����͵ĳ���
*/

#include <stdio.h>

int main(void)
{
	printf("sizeof(char)  = %u\n", (unsigned)sizeof(char));
	printf("sizeof(short) = %u\n", (unsigned)sizeof(short));
	printf("sizeof(int)   = %u\n", (unsigned)sizeof(int));
	printf("sizeof(long)  = %u\n", (unsigned)sizeof(long));
    getchar();
	return 0;
}
/*
sizeof(char)  = 1
sizeof(short) = 2
sizeof(int)   = 4
sizeof(long)  = 4
*/
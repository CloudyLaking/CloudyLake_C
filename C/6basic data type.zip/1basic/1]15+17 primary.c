#include<stdio.h>
int main(void)
{
    printf("%d",15+17);//显示 显示为十进制  15+17结果 "%d",15+17都是实参
    getchar();//加上来防止c程序无法运行
    return 0;
}

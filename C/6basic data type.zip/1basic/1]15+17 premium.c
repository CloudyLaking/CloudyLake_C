#include<stdio.h>
int main(void)
{
    printf("15+17的结果是 %d\n",15+17);//↓要切换国标才能中文，\n是换行的意思
    getchar();//鍔犱笂鏉ラ槻姝�c绋嬪簭鏃犳硶杩愯��
    return 0;
}
